/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GUI;
import java.io.*;
import operator.OperatorModule;
import operator.Bill;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author farah
 */

public class BillsTableGUI extends JFrame {

    public BillsTableGUI(OperatorModule operator, String meterCode) {
        setTitle("Bill Details");
        setSize(600, 400);
        setLocationRelativeTo(null);

        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Meter Code");
        model.addColumn("Old Reading");
        model.addColumn("New Reading");
        model.addColumn("Amount");
        model.addColumn("Status");
        model.addColumn("Region");

        Bill bill = operator.findBillByMeterCode(meterCode);

        if (bill != null) {
            model.addRow(new Object[]{
                bill.getMeterCode(),
                bill.getOldReading(),
                bill.getNewReading(),
                bill.getAmount(),
                bill.getStatus(),
                bill.getRegion()
            });
        } else {
            JOptionPane.showMessageDialog(null, "Bill not found.");
        }

        JTable table = new JTable(model);
        add(new JScrollPane(table));
    }


   public BillsTableGUI(OperatorModule operator, String region, boolean searchByRegion) {
    setTitle("Bills for Region: " + region);
    setSize(600, 400);
    setLocationRelativeTo(null);

    DefaultTableModel model = new DefaultTableModel();
    model.addColumn("Meter Code");
    model.addColumn("Old Reading");
    model.addColumn("New Reading");
    model.addColumn("Amount");
    model.addColumn("Status");
    model.addColumn("Region");

    java.util.List<Bill> list = operator.viewBillsByRegion(region);

    if (list.isEmpty()) {
        JOptionPane.showMessageDialog(null, "No bills found for this region.");
    } else {
        for (Bill bill : list) {
            model.addRow(new Object[]{
                bill.getMeterCode(),
                bill.getOldReading(),
                bill.getNewReading(),
                bill.getAmount(),
                bill.getStatus(),
                bill.getRegion()
            });
        }
    }

    JTable table = new JTable(model);
    add(new JScrollPane(table));
}
}
