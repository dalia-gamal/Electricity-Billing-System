/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package operator;
import java.io.*;
import java.util.*;
/**
 *
 * @author farah
 */
public class OperatorModule {
    private List<Bill> bills = new ArrayList<>();
    public void loadBillsFromFile() {
    bills.clear();
    try (BufferedReader reader = new BufferedReader(new FileReader("bills.txt"))) {
        String line;
        while ((line = reader.readLine()) != null) {
            String[] parts = line.split(",");
            bills.add(new Bill(
                parts[0], // meterCode
                Integer.parseInt(parts[1]), // oldReading
                Integer.parseInt(parts[2]), // newReading
                Double.parseDouble(parts[3]), // amount
                parts[4], // status
                parts[5]  // region
            ));
        }
    } catch (IOException e) {
        e.printStackTrace();
    }
}
public void saveBillsToFile() {
    try (PrintWriter writer = new PrintWriter(new FileWriter("bills.txt"))) {
        for (Bill bill : bills) {
            writer.println(bill.toFileString());
        }
    } catch (IOException e) {
        e.printStackTrace();
    }
}
public boolean collectPayment(String meterCode) {
    Bill bill = findBillByMeterCode(meterCode);
    if (bill != null) {
        bill.setStatus("PAID");  
        return true;
    } else {
        return false;  
    }
}

public String printBill(String meterCode) {
    for (Bill bill : bills) {
        if (bill.getMeterCode().equals(meterCode)) {
            return bill.displayDetails();  // أو رجعي String
        }
    }
    return null;   // هنا الصح
}

public List<Bill> viewBillsByRegion(String region) {
    List<Bill> result = new ArrayList<>();
    for (Bill bill : bills) {
        if (bill.getRegion().equals(region)) {
            result.add(bill);
        }
    }
    return result;
}
public Bill findBillByMeterCode(String meterCode) {
    for (Bill bill : bills) {  // bills دي List<Bill> موجودة في OperatorModule
        if (bill.getMeterCode().equals(meterCode)) {
            return bill;         // رجعنا الكائن اللي لقيناه
        }
    } 
    return null;                 // لو مش موجود رجعنا null
}
 private Map<String, Double> tariffs;        // التعريفات لكل منطقة

    public OperatorModule() {
        bills = new ArrayList<>();
        tariffs = new HashMap<>();
    }

    // مثال على ميثود defineTariff
    public void defineTariff(String region, double rate) {
        tariffs.put(region, rate); // تحديث التعريفة للمنطقة
        System.out.println("Tariff for " + region + " set to " + rate);
    }
    
    
    public boolean stopMeter(String meterCode) {
    Bill bill = findBillByMeterCode(meterCode);
    if (bill != null) {
        bill.setStatus("STOPPED");  // أو "CANCELLED"
        return true;
    } else {
        return false;
    }
}

}
