/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package operator;
import java.util.List;
/**
 *
 * @author farah
 */
public class OperatorFunctions {
 
//    public static void main(String[] args) {
//        // إنشاء الكائن OperatorModule
//        OperatorModule operator = new OperatorModule();
//
//        // 1- تحميل الفواتير من الملف
//        operator.loadBillsFromFile();
//
//        // 2- دفع فاتورة
//        boolean paid = operator.collectPayment("12345");
//        if (paid) {
//            System.out.println("Bill marked as PAID successfully!");
//        } else {
//            System.out.println("Bill not found.");
//        }
//
//        // 3- طباعة الفاتورة
//        operator.printBill("12345");
//
//        // 4- عرض الفواتير حسب المنطقة
//        List<Bill> cairoBills = operator.viewBillsByRegion("Cairo");
//        for (Bill bill : cairoBills) {
//            bill.displayDetails();
//        }
//
//        // 5- حفظ التغييرات في الملف
//        operator.saveBillsToFile();
//    }
}
