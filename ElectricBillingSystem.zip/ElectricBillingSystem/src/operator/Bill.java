/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package operator;

/**
 *
 * @author farah
 */
public class Bill {
    private String meterCode;
    private int oldReading, newReading;
    private double amount;
    private String status;
    private String region;

    public Bill(String meterCode, int oldReading, int newReading, double amount, String status, String region) {
        this.meterCode = meterCode;
        this.oldReading = oldReading;
        this.newReading = newReading;
        this.amount = amount;
        this.status = status;
        this.region = region;
    }

    public String getMeterCode() { return meterCode; }
    public String getStatus() { return status; }
    public String getRegion() { return region; }

    public void markAsPaid() { this.status = "PAID"; }

    public boolean isValidReading(int newReading) {
        return newReading >= oldReading;
    }

    public String  displayDetails() {
        return("Meter: " + meterCode + ", Old: " + oldReading +
                           ", New: " + newReading + ", Amount: " + amount + ", Status: " + status);
    }

    public String toFileString() {
        return meterCode + "," + oldReading + "," + newReading + "," + amount + "," + status + "," + region;
    }

    void setStatus(String status) {
         this.status = status;
    }

    public int getOldReading() {
       return oldReading;
    }

    public  int getNewReading() {
        return newReading;
    }

    public double getAmount() {
        return amount;
    }
}
