/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.admin;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class AdminGUI extends JFrame {

    // Users Tab components
    private JTable usersTable;
    private DefaultTableModel usersModel;
    private JTextField txtSearchId;
    private JButton btnSearchId;
    private JButton btnShowAll;

    // Bills Tab components
    private JTable billsTable;
    private DefaultTableModel billsModel;

    // Statistics Tab components
    private JLabel totalCollectedLabel;
    private JLabel paidCountLabel;
    private JLabel unpaidCountLabel;

    // Data
    private List<Bill> bills;

    public AdminGUI() {
        setTitle("Admin Dashboard");
        setSize(1000,600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Main Tabbed Pane
        JTabbedPane tabbedPane = new JTabbedPane();

        // ===== Users Tab =====
        JPanel usersPanel = new JPanel(new BorderLayout());
        usersModel = new DefaultTableModel(new String[]{
                "ID","Role","Username","Password","Full Name","Blocked"},0);
        usersTable = new JTable(usersModel);
        usersPanel.add(new JScrollPane(usersTable), BorderLayout.CENTER);

        // Search area (NEW)
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchPanel.add(new JLabel("Search by ID:"));
        txtSearchId = new JTextField(8);
        searchPanel.add(txtSearchId);
        btnSearchId = new JButton("Search");
        searchPanel.add(btnSearchId);
        btnShowAll = new JButton("Show All");
        searchPanel.add(btnShowAll);
        usersPanel.add(searchPanel, BorderLayout.NORTH);

        JPanel usersButtons = new JPanel(new GridLayout(1,3,5,5));
        JButton addUserBtn = new JButton("Add User");
        JButton updateUserBtn = new JButton("Update User");
        JButton deleteUserBtn = new JButton("Delete User");
        usersButtons.add(addUserBtn);
        usersButtons.add(updateUserBtn);
        usersButtons.add(deleteUserBtn);
        usersPanel.add(usersButtons, BorderLayout.SOUTH);
        tabbedPane.addTab("Users", usersPanel);

        // ===== Bills Tab =====
        JPanel billsPanel = new JPanel(new BorderLayout());
        billsModel = new DefaultTableModel(new String[]{
                "ID","MeterCode","Month","Region","PrevReading","CurrReading","Consumption","Amount","BillDate","Paid","PaymentDate"},0);
        billsTable = new JTable(billsModel);
        billsPanel.add(new JScrollPane(billsTable), BorderLayout.CENTER);
        JButton loadBillsBtn = new JButton("Load Bills");
        billsPanel.add(loadBillsBtn, BorderLayout.SOUTH);
        tabbedPane.addTab("Bills", billsPanel);

        // ===== Statistics Tab =====
        JPanel statsPanel = new JPanel(new GridLayout(3,1,10,10));
        totalCollectedLabel = new JLabel("Total Collected: 0.0");
        paidCountLabel = new JLabel("Paid Bills: 0");
        unpaidCountLabel = new JLabel("Unpaid Bills: 0");
        totalCollectedLabel.setFont(new Font("Arial",Font.BOLD,16));
        paidCountLabel.setFont(new Font("Arial",Font.BOLD,16));
        unpaidCountLabel.setFont(new Font("Arial",Font.BOLD,16));
        statsPanel.add(totalCollectedLabel);
        statsPanel.add(paidCountLabel);
        statsPanel.add(unpaidCountLabel);
        tabbedPane.addTab("Statistics", statsPanel);

        add(tabbedPane);

        // ===== Load Data Methods =====
        loadUsers();

        // ===== Action Listeners =====
        addUserBtn.addActionListener(e -> { new UserForm(this,null).setVisible(true); loadUsers(); });
        updateUserBtn.addActionListener(e -> {
            int selected = usersTable.getSelectedRow();
            if(selected >= 0){
                int id = Integer.parseInt(usersModel.getValueAt(selected,0).toString());
                User user = UserHandler.getUserById(id);
                if(user != null) new UserForm(this,user).setVisible(true);
                loadUsers();
            } else JOptionPane.showMessageDialog(this,"Select a user to update.");
        });
        deleteUserBtn.addActionListener(e -> {
            int selected = usersTable.getSelectedRow();
            if(selected >= 0){
                int confirm = JOptionPane.showConfirmDialog(this,"Are you sure to delete?");
                if(confirm == JOptionPane.YES_OPTION){
                    int id = Integer.parseInt(usersModel.getValueAt(selected,0).toString());
                    UserHandler.deleteUser(id);
                    loadUsers();
                }
            } else JOptionPane.showMessageDialog(this,"Select a user to delete.");
        });

        loadBillsBtn.addActionListener(e -> loadBills());

        // ===== Search listeners (NEW) =====
        btnSearchId.addActionListener(e -> searchById());
        // Enter key in text field
        txtSearchId.addActionListener(e -> searchById());
        // Show all
        btnShowAll.addActionListener(e -> loadUsers());
    }

    // ===== Methods =====
    private void loadUsers(){
        usersModel.setRowCount(0);
        List<User> users = UserHandler.loadUsers();
        for(User u : users){
            usersModel.addRow(new Object[]{
                    u.getId(), u.getRole(), u.getUsername(), u.getPassword(), u.getFullName(), u.isBlocked()
            });
        }
    }

    // New helper: search and display single user by id
    private void searchById() {
        String txt = txtSearchId.getText().trim();
        if(txt.isEmpty()){
            JOptionPane.showMessageDialog(this, "اكتب الـ ID أولاً", "تنبيه", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int id;
        try {
            id = Integer.parseInt(txt);
        } catch (NumberFormatException nfe) {
            JOptionPane.showMessageDialog(this, "الـ ID لازم يكون رقم صحيح", "خطأ", JOptionPane.ERROR_MESSAGE);
            return;
        }

        User u = UserHandler.getUserById(id);
        if(u == null){
            JOptionPane.showMessageDialog(this, "المستخدم بالـ ID ده مش موجود", "Not found", JOptionPane.INFORMATION_MESSAGE);
            // Optionally clear table or keep previous; here نفضّل نعرض جدول فاضي
            usersModel.setRowCount(0);
        } else {
            usersModel.setRowCount(0);
            usersModel.addRow(new Object[]{
                    u.getId(), u.getRole(), u.getUsername(), u.getPassword(), u.getFullName(), u.isBlocked()
            });
            // select the single row
            if(usersModel.getRowCount() > 0) {
                usersTable.setRowSelectionInterval(0, 0);
            }
        }
    }

    private void loadBills(){
        billsModel.setRowCount(0);
        bills = BillHandler.loadBills(); // تأكد إن عندك BillHandler.java + Bill.java جاهزين
        double totalCollected = 0;
        int paidCount = 0, unpaidCount = 0;
        for(Bill b : bills){
            billsModel.addRow(new Object[]{
                    b.getId(), b.getMeterCode(), b.getMonth(), b.getRegion(),
                    b.getPreviousReading(), b.getCurrentReading(), b.getConsumption(),
                    b.getAmount(), b.getBillDate(), b.isPaid(), b.getPaymentDate()
            });
            if(b.isPaid()) {
                totalCollected += b.getAmount();
                paidCount++;
            } else {
                unpaidCount++;
            }
        }
        totalCollectedLabel.setText("Total Collected: " + totalCollected);
        paidCountLabel.setText("Paid Bills: " + paidCount);
        unpaidCountLabel.setText("Unpaid Bills: " + unpaidCount);
    }

    // ===== MAIN =====
    public static void main(String[] args){
        SwingUtilities.invokeLater(() -> new AdminGUI().setVisible(true));
    }
}
