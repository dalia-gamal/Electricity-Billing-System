/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.admin;
import java.io.*;
import java.util.*;

public class BillHandler {
    private static final String FILE_PATH = "data/bills.txt";

    public static List<Bill> loadBills(){
        List<Bill> bills = new ArrayList<>();
        try(BufferedReader br = new BufferedReader(new FileReader(FILE_PATH))){
            String line;
            while((line = br.readLine()) != null){
                if(line.trim().isEmpty()) continue;
                Bill bill = Bill.fromCsv(line);
                if(bill != null) bills.add(bill);
            }
        } catch(IOException e){
            e.printStackTrace();
        }
        return bills;
    }
}
