/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.admin;

import javax.swing.*;
import java.awt.*;

public class UserForm extends JDialog {
    private JTextField roleField, usernameField, passwordField, fullNameField;
    private JCheckBox blockedCheck;
    private JButton saveBtn, cancelBtn;
    private User user;

    public UserForm(JFrame parent, User user){
        super(parent, true);
        this.user = user;
        setTitle(user == null ? "Add User" : "Update User");
        setSize(400,300);
        setLocationRelativeTo(parent);
        setLayout(new GridLayout(6,2,10,10));

        add(new JLabel("Role:"));
        roleField = new JTextField();
        add(roleField);

        add(new JLabel("Username:"));
        usernameField = new JTextField();
        add(usernameField);

        add(new JLabel("Password:"));
        passwordField = new JTextField();
        add(passwordField);

        add(new JLabel("Full Name:"));
        fullNameField = new JTextField();
        add(fullNameField);

        add(new JLabel("Blocked:"));
        blockedCheck = new JCheckBox();
        add(blockedCheck);

        saveBtn = new JButton("Save");
        cancelBtn = new JButton("Cancel");
        add(saveBtn);
        add(cancelBtn);

        if(user != null){
            roleField.setText(user.getRole());
            usernameField.setText(user.getUsername());
            passwordField.setText(user.getPassword());
            fullNameField.setText(user.getFullName());
            blockedCheck.setSelected(user.isBlocked());
        }

        saveBtn.addActionListener(e -> saveUser());
        cancelBtn.addActionListener(e -> dispose());
    }

    private void saveUser(){
        String role = roleField.getText().trim();
        String username = usernameField.getText().trim();
        String password = passwordField.getText().trim();
        String fullName = fullNameField.getText().trim();
        boolean blocked = blockedCheck.isSelected();

        if(role.isEmpty() || username.isEmpty() || password.isEmpty() || fullName.isEmpty()){
            JOptionPane.showMessageDialog(this,"Please fill all fields.");
            return;
        }

        if(user == null){
            int newId = UserHandler.loadUsers().stream().mapToInt(User::getId).max().orElse(0)+1;
            UserHandler.addUser(new User(newId, role, username, password, fullName, blocked));
        } else {
            user.setRole(role);
            user.setUsername(username);
            user.setPassword(password);
            user.setFullName(fullName);
            user.setBlocked(blocked);
            UserHandler.updateUser(user);
        }
        dispose();
    }
}
