/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.admin;
public class Bill {
    private int id;
    private String meterCode;
    private int month;
    private String region;
    private double previousReading;
    private double currentReading;
    private double consumption;
    private double amount;
    private String billDate;
    private boolean paid;
    private String paymentDate;

    // Constructor
    public Bill(int id, String meterCode, int month, String region,
                double previousReading, double currentReading,
                double consumption, double amount,
                String billDate, boolean paid, String paymentDate){
        this.id = id;
        this.meterCode = meterCode;
        this.month = month;
        this.region = region;
        this.previousReading = previousReading;
        this.currentReading = currentReading;
        this.consumption = consumption;
        this.amount = amount;
        this.billDate = billDate;
        this.paid = paid;
        this.paymentDate = paymentDate;
    }

    // Getters
    public int getId(){ return id; }
    public String getMeterCode(){ return meterCode; }
    public int getMonth(){ return month; }
    public String getRegion(){ return region; }
    public double getPreviousReading(){ return previousReading; }
    public double getCurrentReading(){ return currentReading; }
    public double getConsumption(){ return consumption; }
    public double getAmount(){ return amount; }
    public String getBillDate(){ return billDate; }
    public boolean isPaid(){ return paid; }
    public String getPaymentDate(){ return paymentDate; }

    // Static method to create Bill from CSV line
    public static Bill fromCsv(String line){
        String[] parts = line.split(",");
        if(parts.length < 11) return null;
        int id = Integer.parseInt(parts[0]);
        String meterCode = parts[1];
        int month = Integer.parseInt(parts[2]);
        String region = parts[3];
        double previousReading = Double.parseDouble(parts[4]);
        double currentReading = Double.parseDouble(parts[5]);
        double consumption = Double.parseDouble(parts[6]);
        double amount = Double.parseDouble(parts[7]);
        String billDate = parts[8];
        boolean paid = Boolean.parseBoolean(parts[9]);
        String paymentDate = parts[10];
        return new Bill(id,meterCode,month,region,previousReading,currentReading,consumption,amount,billDate,paid,paymentDate);
    }
}
