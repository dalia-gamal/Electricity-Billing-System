/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.admin;
import java.io.*;
import java.util.*;

public class UserHandler {
    private static final String FILE_PATH = "data/users.txt";

    // Load all users
    public static List<User> loadUsers() {
        List<User> users = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while((line = br.readLine()) != null){
                if(line.trim().isEmpty()) continue;
                String[] parts = line.split(",");
                if(parts.length >= 6){
                    int id = Integer.parseInt(parts[0]);
                    String role = parts[1];
                    String username = parts[2];
                    String password = parts[3];
                    String fullName = parts[4];
                    boolean blocked = Boolean.parseBoolean(parts[5]);
                    users.add(new User(id, role, username, password, fullName, blocked));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return users;
    }

    // Get user by ID
    public static User getUserById(int id){
        for(User u : loadUsers()){
            if(u.getId() == id) return u;
        }
        return null;
    }

    // Add new user
    public static void addUser(User user){
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_PATH,true))){
            bw.write(userToLine(user));
            bw.newLine();
        } catch (IOException e){ e.printStackTrace(); }
    }

    // Update existing user
    public static void updateUser(User user){
        List<User> users = loadUsers();
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_PATH,false))){
            for(User u : users){
                if(u.getId() == user.getId()) bw.write(userToLine(user));
                else bw.write(userToLine(u));
                bw.newLine();
            }
        } catch(IOException e){ e.printStackTrace(); }
    }

    // Delete user
    public static void deleteUser(int id){
        List<User> users = loadUsers();
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_PATH,false))){
            for(User u : users){
                if(u.getId() != id){
                    bw.write(userToLine(u));
                    bw.newLine();
                }
            }
        } catch(IOException e){ e.printStackTrace(); }
    }

    // Convert user to CSV line
    private static String userToLine(User user){
        return user.getId() + "," + user.getRole() + "," + user.getUsername() + "," +
               user.getPassword() + "," + user.getFullName() + "," + user.isBlocked();
    }
}
