/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.admin;

public class User {
    private int id;
    private String role;
    private String username;
    private String password;
    private String fullName;
    private boolean blocked;

    public User(int id, String role, String username, String password, String fullName, boolean blocked) {
        this.id = id;
        this.role = role;
        this.username = username;
        this.password = password;
        this.fullName = fullName;
        this.blocked = blocked;
    }

    
    public int getId() {
        return id;
    }
    public String getRole() {
        return role;
    }
    public String getUsername() {
        return username;
    }
    public String getPassword() {
        return password; 
    }
    public String getFullName() {
        return fullName;
    }
    public boolean isBlocked() {
        return blocked;
    }

    // SETTERS
    public void setRole(String role) {
        this.role = role;
    }
    public void setUsername(String username) { 
        this.username = username;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public void setFullName(String fullName) { 
        this.fullName = fullName; 
    }
    public void setBlocked(boolean blocked) {
        this.blocked = blocked;
    }
}
