/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.electricitybillingsystem;

/**
 *
 * @author alaa
 */
import java.time.LocalDate;

public class complaint {
    private String complaintId;
    private String meterCode;
    private String message;
    private LocalDate date;
    private ComplaintStatus status;

   
    public complaint(String complaintId, String meterCode, String message, ComplaintStatus status) {
        this.complaintId = complaintId;
        this.meterCode = meterCode;
        this.message = message;
        this.date = LocalDate.now(); // تاريخ تلقائي
        this.status = status;
    }

    // ----------- Getters -----------
    public String getComplaintId() {
        return complaintId;
    }

    public String getMeterCode() {
        return meterCode;
    }

    public String getMessage() {
        return message;
    }

    public LocalDate getDate() {
        return date;
    }

    public ComplaintStatus getStatus() {
        return status;
    }

    public void setStatus(ComplaintStatus status) {
        this.status = status;
    }

    
    public void saveToFile() {
        FileHandler.appendToFile("complaints.txt",
                complaintId + "|" + meterCode + "|" + message + "|" + date + "|" + status);
    }

    
    public static complaint loadByMeterCode(String meterCode) {
        java.util.List<String> lines = FileHandler.readFromFile("complaints.txt");

        for (String line : lines) {
            String[] p = line.split("\\|");

            if (p[1].equals(meterCode)) {
                return new complaint(
                        p[0],                        
                        p[1],                        
                        p[2],                        
                        ComplaintStatus.valueOf(p[4]) 
                );
            }
        }
        return null;
    }

   
    public static String generateComplaintId() {
        return "C" + System.currentTimeMillis();
    }
}


