/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.electricitybillingsystem;

/**
 *
 * @author alaa
 */
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class FileHandler {

    
    public static void appendToFile(String fileName, String line) {
        try {
            FileWriter fw = new FileWriter(fileName, true);
            fw.write(line + "\n");
            fw.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

   
    public static List<String> readFromFile(String fileName) {
        List<String> data = new ArrayList<>();

        try {
            File f = new File(fileName);
            if (!f.exists()) return data; 

            BufferedReader br = new BufferedReader(new FileReader(f));
            String line;

            while ((line = br.readLine()) != null) {
                data.add(line);
            }

            br.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return data;
    }

    
    public static void overwriteFile(String fileName, List<String> newLines) {
        try {
            FileWriter fw = new FileWriter(fileName, false);

            for (String line : newLines) {
                fw.write(line + "\n");
            }

            fw.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
