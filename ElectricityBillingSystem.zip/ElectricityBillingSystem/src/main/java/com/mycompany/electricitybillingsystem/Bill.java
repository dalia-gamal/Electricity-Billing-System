/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.electricitybillingsystem;

/**
 *
 * @author alaa
 */
public class Bill {

    private String billId;
    private String meterCode;
    private String month;
    private double oldReading;
    private double newReading;
    private double amount;
    private BillStatus status;

    public Bill(String billId, String meterCode, String month, double oldReading,
                double newReading, double amount, BillStatus status) {

        this.billId = billId;
        this.meterCode = meterCode;
        this.month = month;
        this.oldReading = oldReading;
        this.newReading = newReading;
        this.amount = amount;
        this.status = status;
    }

    // ----------- Getters ------------
    public String getBillId()     { return billId; }
    public String getMeterCode()  { return meterCode; }
    public String getMonth()      { return month; }
    public double getOldReading() { return oldReading; }
    public double getNewReading() { return newReading; }
    public double getAmount()     { return amount; }
    public BillStatus getStatus() { return status; }

    public void setStatus(BillStatus status) {
        this.status = status;
    }

    // ----------- Convert to string -----------
    @Override
    public String toString() {
        return billId + "|" + meterCode + "|" + month + "|" +
                oldReading + "|" + newReading + "|" + amount + "|" + status;
    }

    // ----------- Convert string → object -----------
    public static Bill fromString(String line) {
        String[] p = line.split("\\|");
        return new Bill(
                p[0],                           // billId
                p[1],                           // meterCode
                p[2],                           // month
                Double.parseDouble(p[3]),       // oldReading
                Double.parseDouble(p[4]),       // newReading
                Double.parseDouble(p[5]),       // amount
                BillStatus.valueOf(p[6])        // status (ENUM)
        );
    }

    // ----------- Save to file -----------
    public void saveToFile() {
        FileHandler.appendToFile("bills.txt", this.toString());
    }

    // ----------- Load bill by meter code -----------
    public static Bill loadByMeterCode(String meterCode) {
        java.util.List<String> lines = FileHandler.readFromFile("bills.txt");

        for (String line : lines) {
            if (line.trim().isEmpty()) continue;

            Bill b = Bill.fromString(line);
            if (b.getMeterCode().equals(meterCode)) {
                return b;
            }
        }

        return null;
    }
}
