/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.electricitybillingsystem;

/**
 *
 * @author alaa
 */
import javax.swing.*;

public class CustomerDashboardGui extends JFrame {

    public CustomerDashboardGui() {
        setTitle("Old Customer Dashboard");
        setSize(300, 250);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JButton btnPay = new JButton("Pay Bill");
        JButton btnReading = new JButton("Enter Reading");
        JButton btnComplaint = new JButton("Submit Complaint");

        btnPay.addActionListener(e -> new payBillGui().setVisible(true));
        btnReading.addActionListener(e -> new ReadingGui().setVisible(true));
        btnComplaint.addActionListener(e -> new ComplainGui().setVisible(true));

        setLayout(new java.awt.GridLayout(3, 1, 10, 10));
        add(btnPay);
        add(btnReading);
        add(btnComplaint);
    }
}

