/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.electricitybillingsystem;

/**
 *
 * @author alaa
 */
import javax.swing.*;

public class payBillGui  extends JFrame {

    public payBillGui () {
        setTitle("Pay Bill");
        setSize(300, 200);
        setLocationRelativeTo(null);

        JTextField meterField = new JTextField();
        JButton payBtn = new JButton("Pay");

        payBtn.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Payment Successful");
        });

        setLayout(new java.awt.GridLayout(3, 1, 10, 10));
        add(new JLabel("Meter Code:"));
        add(meterField);
        add(payBtn);
    }
}
