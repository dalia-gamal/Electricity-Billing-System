/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.electricitybillingsystem;

/**
 *
 * @author alaa
 */
import javax.swing.*;

public class ReadingGui extends JFrame {

    public ReadingGui() {
        setTitle("Enter Reading");
        setSize(300, 200);
        setLocationRelativeTo(null);

        JTextField readingField = new JTextField();
        JButton submitBtn = new JButton("Submit");

        submitBtn.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Reading Submitted");
        });

        setLayout(new java.awt.GridLayout(3, 1, 10, 10));
        add(new JLabel("New Reading:"));
        add(readingField);
        add(submitBtn);
    }
}
