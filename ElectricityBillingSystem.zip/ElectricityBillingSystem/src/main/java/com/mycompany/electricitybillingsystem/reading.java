/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.electricitybillingsystem;

/**
 *
 * @author alaa
 */
import java.time.LocalDate;
import java.util.List;

public class reading {
    private String metercode;
    private LocalDate date;
    private int previousReading;
    private int newReading;
    private ReadingStatus status;

    public reading(String meterCode, String date, int previousReading, int newReading, ReadingStatus status) {
        this.metercode = meterCode;
        this.date = LocalDate.now();
        this.previousReading = previousReading;
        this.newReading = newReading;
        this.status = status;
    }

    public String getMetercode() {
        return metercode;
    }

    public LocalDate getDate() {
        return date;
    }

    public int getPreviousReading() {
        return previousReading;
    }

    public int getNewReading() {
        return newReading;
    }

    public ReadingStatus getStatus() {
        return status;
    }

    public void setStatus(ReadingStatus status) {
        this.status = status;
    }

    public void saveToFile() {
        String line = metercode + "|" + date + "|" + previousReading + "|" + newReading + "|" + status;
        FileHandler.appendToFile("readings.txt", line);
    }

    public reading loadByMeterCode(String meterCode) {
        List<String> lines = FileHandler.readFromFile("readings.txt");

        for (String line : lines) {
            String[] p = line.split("\\|");

            if (p[0].equals(meterCode)) {
                return new reading(
                    p[0],
                    p[1],
                    Integer.parseInt(p[2]),
                    Integer.parseInt(p[3]),
                    ReadingStatus.valueOf(p[4])
                );
            }
        }

        return null; 
    }
}