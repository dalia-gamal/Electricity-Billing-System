/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.electricitybillingsystem;

/**
 *
 * @author alaa
 */
import javax.swing.*;

public class ComplainGui extends JFrame {

    public ComplainGui() {
        setTitle("Submit Complaint");
        setSize(300, 250);
        setLocationRelativeTo(null);

        JTextArea area = new JTextArea();
        JButton submitBtn = new JButton("Submit");

        submitBtn.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Complaint Sent");
        });

        setLayout(new java.awt.BorderLayout());
        add(new JLabel("Complaint:"), java.awt.BorderLayout.NORTH);
        add(new JScrollPane(area), java.awt.BorderLayout.CENTER);
        add(submitBtn, java.awt.BorderLayout.SOUTH);
    }
}
