/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.electricitybillingsystem;

/**
 *
 * @author alaa
 */
import java.util.List;

public class ElectricityBillingSystem {

    public static void main(String[] args) {
        
         new CustomerDashboardGui().setVisible(true);
        System.out.println("==== Test Reading ====");
        reading r1 = new reading("M001", "2025-12-12", 100, 150, ReadingStatus.PENDING);
        r1.saveToFile();
        reading rLoaded = r1.loadByMeterCode("M001");
        System.out.println("Loaded Reading: " + rLoaded.getMetercode() + " | Previous: "
                + rLoaded.getPreviousReading() + " | New: " + rLoaded.getNewReading());

        System.out.println("\n==== Test Bill ====");
        Bill b1 = new Bill("B001", "M001", "December", 100, 150, 75.5, BillStatus.UNPAID);
        b1.saveToFile();
        Bill bLoaded = Bill.loadByMeterCode("M001");
        System.out.println("Loaded Bill: " + bLoaded.getBillId() + " | Meter: " + bLoaded.getMeterCode()
                + " | Amount: " + bLoaded.getAmount() + " | Status: " + bLoaded.getStatus());

        System.out.println("\n==== Test Complaint ====");
        complaint c1 = new complaint(complaint.generateComplaintId(), "M001", "Meter not working", ComplaintStatus.PENDING);
        c1.saveToFile();
        complaint cLoaded = complaint.loadByMeterCode("M001");
        System.out.println("Loaded Complaint: " + cLoaded.getComplaintId() + " | Meter: " 
                + cLoaded.getMeterCode() + " | Message: " + cLoaded.getMessage()
                + " | Status: " + cLoaded.getStatus());

        System.out.println("\n==== All lines in files ====");
        List<String> readingsLines = FileHandler.readFromFile("readings.txt");
        List<String> billsLines = FileHandler.readFromFile("bills.txt");
        List<String> complaintsLines = FileHandler.readFromFile("complaints.txt");

        System.out.println("Readings.txt: " + readingsLines);
        System.out.println("Bills.txt: " + billsLines);
        System.out.println("Complaints.txt: " + complaintsLines);
    }
}
    
    

