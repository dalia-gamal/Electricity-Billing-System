package services.impl;

import models.users.Admin;
import models.users.Customer;
import models.users.Operator;
import models.users.User;
import services.interfaces.AuthService;
import utils.UserFileManager;
import java.util.List;

/**
 * Authentication Service Implementation
 * Simple file-based authentication
 */
public class AuthServiceImpl implements AuthService {
    private User currentUser;

    @Override
    public User login(String username, String password) {
        // Validate inputs
        if (username == null || username.trim().isEmpty() ||
            password == null || password.trim().isEmpty()) {
            return null;
        }

        // Load users from file
        List<User> users = UserFileManager.loadUsers();

        // Find matching user
        for (User user : users) {
            if (user.getUsername().equals(username) &&
                user.getPassword().equals(password)) {

                // Create specific user type based on role
                User typedUser = createTypedUser(user);
                currentUser = typedUser;
                return typedUser;
            }
        }

        return null;
    }

    /**
     * Create the correct user type based on role
     */
    private User createTypedUser(User user) {
        String role = user.getRole().toLowerCase();

        switch (role) {
            case "admin":
                Admin admin = new Admin();
                admin.setUsername(user.getUsername());
                admin.setPassword(user.getPassword());
                admin.setRole(user.getRole());
                admin.setFullName(user.getFullName());
                return admin;

            case "operator":
                Operator operator = new Operator();
                operator.setUsername(user.getUsername());
                operator.setPassword(user.getPassword());
                operator.setRole(user.getRole());
                operator.setFullName(user.getFullName());
                return operator;

            case "customer":
                Customer customer = new Customer();
                customer.setUsername(user.getUsername());
                customer.setPassword(user.getPassword());
                customer.setRole(user.getRole());
                customer.setFullName(user.getFullName());
                return customer;

            default:
                return user; // Return generic User if role is unknown
        }
    }

    @Override
    public void logout() {
        currentUser = null;
    }

    @Override
    public User getCurrentUser() {
        return currentUser;
    }
}
