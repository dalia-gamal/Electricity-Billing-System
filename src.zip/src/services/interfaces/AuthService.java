package services.interfaces;

import models.users.User;

/**
 * Authentication Service Interface
 */
public interface AuthService {
    /**
     * Login user with username and password
     * @return User object if login successful, null otherwise
     */
    User login(String username, String password);

    /**
     * Logout current user
     */
    void logout();

    /**
     * Get currently logged in user
     */
    User getCurrentUser();
}
