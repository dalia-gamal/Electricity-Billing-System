package models.users;

/**
 * Admin user model
 * Extends base User class
 */
public class Admin extends User {

    public Admin() {
        super();
    }

    public Admin(String username, String password, String fullName) {
        super(username, password, "admin", fullName);
    }

    @Override
    public String toString() {
        return "Admin{username='" + getUsername() + "', fullName='" + getFullName() + "'}";
    }
}
