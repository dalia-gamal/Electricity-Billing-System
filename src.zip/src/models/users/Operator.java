package models.users;

/**
 * Operator user model
 * Extends base User class
 */
public class Operator extends User {

    public Operator() {
        super();
    }

    public Operator(String username, String password, String fullName) {
        super(username, password, "operator", fullName);
    }

    @Override
    public String toString() {
        return "Operator{username='" + getUsername() + "', fullName='" + getFullName() + "'}";
    }
}
