package models.users;

/**
 * Customer user model
 * Extends base User class
 */
public class Customer extends User {

    public Customer() {
        super();
    }

    public Customer(String username, String password, String fullName) {
        super(username, password, "customer", fullName);
    }

    @Override
    public String toString() {
        return "Customer{username='" + getUsername() + "', fullName='" + getFullName() + "'}";
    }
}
