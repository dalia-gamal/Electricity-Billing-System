package utils;

import models.users.User;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Manages user data in text file
 * Format: username,password,role,fullName
 */
public class UserFileManager {
    private static final String FILE_PATH = "data/users.txt";

    /**
     * Load all users from file
     */
    public static List<User> loadUsers() {
        List<User> users = new ArrayList<>();
        File file = new File(FILE_PATH);

        if (!file.exists()) {
            createDefaultUsers();
            return loadUsers();
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 4) {
                    User user = new User(parts[0], parts[1], parts[2], parts[3]);
                    users.add(user);
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading users file: " + e.getMessage());
        }

        return users;
    }

    /**
     * Save users to file
     */
    public static void saveUsers(List<User> users) {
        File file = new File(FILE_PATH);
        file.getParentFile().mkdirs();

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (User user : users) {
                writer.write(user.getUsername() + "," +
                           user.getPassword() + "," +
                           user.getRole() + "," +
                           user.getFullName());
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Error saving users file: " + e.getMessage());
        }
    }

    /**
     * Create default users for testing
     */
    private static void createDefaultUsers() {
        List<User> defaultUsers = new ArrayList<>();
        defaultUsers.add(new User("admin", "admin123", "admin", "System Administrator"));
        defaultUsers.add(new User("operator1", "op123", "operator", "Ahmed Hassan"));
        defaultUsers.add(new User("customer1", "cust123", "customer", "Mohamed Ali"));
        saveUsers(defaultUsers);
    }

    /**
     * Add a new user
     */
    public static boolean addUser(User newUser) {
        List<User> users = loadUsers();

        // Check if username already exists
        for (User user : users) {
            if (user.getUsername().equals(newUser.getUsername())) {
                return false;
            }
        }

        users.add(newUser);
        saveUsers(users);
        return true;
    }
}
