package ui;

import models.users.User;
import ui.auth.LoginFrame;
import javax.swing.*;
import java.awt.*;

/**
 * Simple Dashboard Frame - Shows user info after login
 */
public class DashboardFrame extends JFrame {

    private User currentUser;

    private JPanel mainPanel;
    private JLabel titleLabel;
    private JLabel usernameLabel;
    private JLabel fullNameLabel;
    private JLabel roleLabel;
    private JLabel userTypeLabel;
    private JButton logoutButton;

    public DashboardFrame(User user) {
        this.currentUser = user;
        initializeComponents();
        setupLayout();
        setupFrame();
    }

    private void initializeComponents() {
        mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBackground(Color.WHITE);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(40, 50, 40, 50));

        // Title
        titleLabel = new JLabel("Dashboard - Welcome!");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 28));
        titleLabel.setForeground(new Color(41, 128, 185));
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        // User Info
        String userType = currentUser.getClass().getSimpleName();

        usernameLabel = createInfoLabel("Username: " + currentUser.getUsername());
        fullNameLabel = createInfoLabel("Full Name: " + currentUser.getFullName());
        roleLabel = createInfoLabel("Role: " + currentUser.getRole().toUpperCase());
        userTypeLabel = createInfoLabel("User Type: " + userType);

        // Logout Button
        logoutButton = new JButton("Logout");
        logoutButton.setFont(new Font("Arial", Font.BOLD, 14));
        logoutButton.setBackground(new Color(231, 76, 60));
        logoutButton.setForeground(Color.WHITE);
        logoutButton.setFocusPainted(false);
        logoutButton.setBorderPainted(false);
        logoutButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        logoutButton.setPreferredSize(new Dimension(150, 40));
        logoutButton.setMaximumSize(new Dimension(150, 40));
        logoutButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        logoutButton.addActionListener(e -> handleLogout());
    }

    private JLabel createInfoLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Arial", Font.PLAIN, 16));
        label.setAlignmentX(Component.CENTER_ALIGNMENT);
        return label;
    }

    private void setupLayout() {
        mainPanel.add(titleLabel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 40)));

        mainPanel.add(usernameLabel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 15)));

        mainPanel.add(fullNameLabel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 15)));

        mainPanel.add(roleLabel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 15)));

        mainPanel.add(userTypeLabel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 40)));

        mainPanel.add(logoutButton);
    }

    private void handleLogout() {
        int confirm = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to logout?",
            "Confirm Logout",
            JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            dispose();
            // Open login screen again
            SwingUtilities.invokeLater(() -> {
                LoginFrame loginFrame = new LoginFrame();
                loginFrame.setVisible(true);
            });
        }
    }

    private void setupFrame() {
        setTitle("Dashboard - " + currentUser.getFullName());
        setContentPane(mainPanel);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 400);
        setLocationRelativeTo(null);
        setResizable(false);
    }
}
